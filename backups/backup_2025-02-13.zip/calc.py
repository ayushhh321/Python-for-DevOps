num1 = input("Enter your number 1 : ") #in this case value input as string hoga then if you add two number it will concatnate

num1 = int(input("Num1: ")) #now num1 will be typecasted to integer

num2 = int(input("Num2: "))

sum = num1+ num2

print("sum of two numnbers is: ", sum)

Difference = num1-num2

print("Difference of two numnbers is: ", Difference)

product = num1* num2

print("product of two numnbers is: ", product)

remenainder = num1% num2

print("remenainder of two numnbers is: ", remenainder)

quotient = num1/num2

print("quotient of two numnbers is: ", quotient)