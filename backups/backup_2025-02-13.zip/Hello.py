
name = input("Whats ur name: ")
name_var="Ayush"  #now kuch bhi dalo in name it will be overwritten by name_var
env ="dev" #constant
print("Hello",name)