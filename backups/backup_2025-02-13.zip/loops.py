#LIST

list_of_cloud = ["aws","azure","gcp"]
print(list_of_cloud)

#adding element to list
list_of_cloud.append("salesforce")
print(list_of_cloud)

#adding element at position 
list_of_cloud.insert(2,"Alibaba")
print(list_of_cloud)

#LENGTH
print(len(list_of_cloud))

#LOOPS

for cloud in list_of_cloud:
  print(cloud)
  
# printing numbers in range using Range keyword

for i in range(0,10):
  print(hello)