import os 

print(os.system("df -h"))  # Display disk space usage
print(os.system("uptime")) # Display system uptime
print(os.system("free -h")) #Display memory usage or RAM usage